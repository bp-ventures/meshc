# Mesh Connect - Mock Web UI

A simple, single-file mock UI for testing Mesh Connect deposit flows locally. No dependencies, no server required.

## Quick Start

### Step 1: Generate Link Token

```bash
cd /path/to/meshc
source .venv/bin/activate
meshc sandbox-cex
```

**Copy the link token** from the output (the long base64 string).

### Step 2: Open Mock UI

Open `mock-ui/index.html` in your browser:

```bash
# Option 1: Direct open (macOS)
open mock-ui/index.html

# Option 2: Direct open (Linux)
xdg-open mock-ui/index.html

# Option 3: Double-click the file in your file explorer
```

### Step 3: Paste & Test

1. **Paste the link token** into the text area
2. Click **"Decode & Start"**
3. Walk through the flow:
   - 📋 View decoded token information
   - 🏦 Select an exchange (Coinbase, Binance, etc.)
   - 🔐 Login with any credentials (e.g., `user123` / `pass123`)
   - 💰 Select an asset (USDC, BTC, ETH, SOL)
   - ✅ Review and confirm
   - ⏳ Watch processing animation
   - 🎉 See success with mock transaction hash

## Features

✅ **Zero dependencies** - Pure HTML/CSS/JavaScript
✅ **Offline capable** - No external resources
✅ **Token decoder** - See what's inside your link token
✅ **Full flow simulation** - Exchange selection → Login → Asset selection → Review → Success
✅ **Webhook payload** - Copy mock webhook JSON for testing
✅ **Mobile responsive** - Works on any device

## What Gets Mocked

- **Exchange catalog** - Coinbase, Binance, Kraken, Gemini
- **Authentication** - Any username/password works
- **Account balances** - Pre-populated with fake balances
- **Transfer processing** - 2-second simulated delay
- **Transaction hash** - Randomly generated 0x... hash
- **Webhook event** - Complete JSON payload you can copy

## Testing Webhooks

After completing the mock flow:

1. Expand the **"📡 Webhook Payload"** section on the success screen
2. Copy the JSON payload
3. Go to [webhook.site](https://webhook.site)
4. Use their "Edit & Resend" feature to POST the payload

Or use `curl`:

```bash
curl -X POST https://webhook.site/your-unique-url \
  -H "Content-Type: application/json" \
  -d '{"type":"transfer.completed","status":"succeeded",...}'
```

## File Structure

```
mock-ui/
├── index.html          # Single-file app (everything embedded)
└── README.md           # This file
```

## How It Works

1. **Link token decoding**: Uses JavaScript's `atob()` to decode the base64 token
2. **URL parsing**: Extracts query parameters from the decoded URL
3. **State management**: Simple JavaScript object tracks selection state
4. **Screen navigation**: Show/hide divs with CSS classes
5. **Mock data**: Hardcoded exchanges, assets, and balances
6. **Random generation**: Transaction IDs and hashes generated client-side

## Limitations

This is a **mock UI for testing only**. It does NOT:

- Connect to real exchanges or wallets
- Make actual API calls to Mesh
- Move real money or crypto
- Validate addresses or network IDs
- Support wallet flows (MetaMask, etc.)
- Persist data across page refreshes

## Extending

Want to add more features? The code is intentionally simple:

- **Add exchanges**: Update the `exchange-grid` HTML
- **Add assets**: Update the `asset-list` HTML
- **Add error scenarios**: Add conditional logic in `confirmTransfer()`
- **Add wallet flow**: Create new screen for wallet connection simulation

## Troubleshooting

**"Invalid link token" error**
- Make sure you copied the entire base64 string (no line breaks)
- Check that you're using a token from `meshc sandbox-cex`

**Page doesn't open**
- Make sure you have a modern browser (Chrome, Firefox, Safari)
- Check browser console (F12) for JavaScript errors

**Styling looks broken**
- Ensure you opened `index.html` (not just viewing as plain text)
- Try a different browser

## Related Commands

```bash
# Generate CEX (exchange) token
meshc sandbox-cex

# Generate wallet token (Sepolia testnet)
meshc sandbox-wallet --address 0xYourAddress

# List all networks
meshc networks

# Check transfer status
meshc status <transaction-id>
```

## Real Integration

To integrate the real Mesh Connect Link UI:

```javascript
import { createLink } from "@meshconnect/web-link-sdk";

const meshLink = createLink({
  clientId: "YOUR_CLIENT_ID",
  onTransferFinished: (result) => {
    console.log("Transfer:", result.status);
  }
});

meshLink.openLink(linkToken);
```

See `TESTING.md` for full integration guide.
